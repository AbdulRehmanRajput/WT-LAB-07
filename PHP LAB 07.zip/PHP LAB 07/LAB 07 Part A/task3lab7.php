
<?php 
// PHP program to calculate the sum of digits 
function sum($num) { 
    $sum = 0; 
    for ($i = 0; $i < strlen($num); $i++){ 
        $sum += $num[$i]; 
    } 
    return $sum; 
} 
  
// Driver Code 
$num = "71"; 
if ($num == "75") {
    echo "It’s your lucky day today";
} else {
    echo "It’s not your lucky day today";
}
?>