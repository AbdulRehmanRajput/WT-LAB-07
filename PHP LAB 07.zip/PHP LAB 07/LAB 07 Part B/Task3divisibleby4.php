<?php
 echo implode(",",range(200,250,4))."\n";
?>