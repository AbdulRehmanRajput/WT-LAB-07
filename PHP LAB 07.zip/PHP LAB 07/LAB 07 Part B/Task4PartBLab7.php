<?php
$input = array(8, "8", "3", 5, 3, "3",6,"6",3);
$output = array_unique($input);
print_r($output);
?>